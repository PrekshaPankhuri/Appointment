package coding.insight.cleanuiloginregister;

public class Blood {

    String Name,Address,City,BloodBank,Number;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getBloodBank() {
        return BloodBank;
    }

    public String getNumber() {
        return Number;
    }
}
