package coding.insight.cleanuiloginregister;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BloodAdapter extends RecyclerView.Adapter<BloodAdapter.BloodViewHolder>{

    Context context;
    ArrayList<Blood> list;

    public BloodAdapter(Context context, ArrayList<Blood> list) {
        this.context = context;
        this.list = list;
    }

    public static class BloodViewHolder extends RecyclerView.ViewHolder{

        TextView Name,Address,City,Number,BloodBank;

        public BloodViewHolder(@NonNull View itemView) {
            super(itemView);

            Name=itemView.findViewById(R.id.Name);
            Address=itemView.findViewById(R.id.Address);
            City=itemView.findViewById(R.id.City);
            Number=itemView.findViewById(R.id.Number);
            BloodBank=itemView.findViewById(R.id.BloodBank);

        }
    }

    @NonNull
    @Override
    public BloodAdapter.BloodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.bloodlist,parent,false);
        return new BloodViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BloodAdapter.BloodViewHolder holder, int position) {
        Blood blood=list.get(position);
        holder.Name.setText(blood.getName());
        holder.Address.setText(blood.getAddress());
        holder.City.setText(blood.getCity());
        holder.Number.setText(blood.getNumber());
        holder.BloodBank.setText(blood.getBloodBank());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
