package coding.insight.cleanuiloginregister;

public class O2 {
    String Name,Address,City,Cylinders,Number;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getCylinders() {
        return Cylinders;
    }

    public String getNumber() {
        return Number;
    }
}
