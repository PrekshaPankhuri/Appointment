package coding.insight.cleanuiloginregister;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class O2Adapter extends RecyclerView.Adapter<O2Adapter.O2ViewHolder>{

    Context context;
    ArrayList<O2> list;

    public O2Adapter(Context context, ArrayList<O2> list) {
        this.context = context;
        this.list = list;
    }

    public static class O2ViewHolder extends RecyclerView.ViewHolder{

        TextView Name,Address,City,Number,Cylinder;

        public O2ViewHolder(@NonNull View itemView) {
            super(itemView);

            Name=itemView.findViewById(R.id.Name);
            Address=itemView.findViewById(R.id.Address);
            City=itemView.findViewById(R.id.City);
            Number=itemView.findViewById(R.id.Number);
            Cylinder=itemView.findViewById(R.id.Cylinder);
        }
    }

    @NonNull
    @Override
    public O2Adapter.O2ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=LayoutInflater.from(context).inflate(R.layout.oxygenlist,parent,false);
        return new O2ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull O2Adapter.O2ViewHolder holder, int position) {
        O2 o2=list.get(position);
        holder.Name.setText(o2.getName());
        holder.Address.setText(o2.getAddress());
        holder.City.setText(o2.getCity());
        holder.Number.setText(o2.getNumber());
        holder.Cylinder.setText(o2.getCylinders());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
