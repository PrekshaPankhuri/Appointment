package coding.insight.cleanuiloginregister;

public class Vacc {
}
