package coding.insight.cleanuiloginregister;

public class BookingModel {

    String Name,Address,City,Number;

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getNumber() {
        return Number;
    }
}
