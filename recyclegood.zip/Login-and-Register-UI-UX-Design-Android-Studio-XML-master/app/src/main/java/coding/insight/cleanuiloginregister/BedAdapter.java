package coding.insight.cleanuiloginregister;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BedAdapter extends RecyclerView.Adapter<BedAdapter.BedViewHolder> {

    Context context;

    ArrayList<Beds> list;

    public BedAdapter(Context context, ArrayList<Beds> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public BedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.bedslist,parent,false);
        return new BedViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BedViewHolder holder, int position) {

        Beds beds = list.get(position);
        holder.Name.setText(beds.getName());
        holder.Address.setText(beds.getAddress());
        holder.City.setText(beds.getCity());
        holder.Beds.setText(beds.getBeds());
        holder.Number.setText(beds.getNumber());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class BedViewHolder extends RecyclerView.ViewHolder{

        TextView Name,Address,City,Beds,Number;

        public BedViewHolder(@NonNull View itemView){
            super(itemView);

            Name=itemView.findViewById(R.id.Name);
            Address=itemView.findViewById(R.id.Address);
            City=itemView.findViewById(R.id.City);
            Beds=itemView.findViewById(R.id.Beds);
            Number=itemView.findViewById(R.id.Number);

        }
    }
}
